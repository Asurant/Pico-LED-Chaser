from machine import Pin
import time

leds = [
    Pin(1, Pin.OUT),
    Pin(2, Pin.OUT),
    Pin(3, Pin.OUT),
    Pin(4, Pin.OUT),
    Pin(5, Pin.OUT),
    Pin(6, Pin.OUT),
    Pin(7, Pin.OUT),
    Pin(8, Pin.OUT),
    Pin(9, Pin.OUT),
    Pin(10, Pin.OUT)
]
button = Pin(0, Pin.IN)

loop = False

while True:
    if button.value() == 0:
        if loop == False:
            loop = True
        else:
            loop = False
        time.sleep(0.2)

    if loop:
        for led in leds:
            if button.value() == 0:
                loop = False
                time.sleep(0.3)
                break
            led.on()
            time.sleep(0.1)
            led.off()
            time.sleep(0.1)